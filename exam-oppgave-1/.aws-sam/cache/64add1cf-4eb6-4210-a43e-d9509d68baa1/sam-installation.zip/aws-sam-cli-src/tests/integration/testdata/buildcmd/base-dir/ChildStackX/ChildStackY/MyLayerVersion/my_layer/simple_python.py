def layer_ping():
    return "This is a Layer Ping from simple_python"
