"""
SAM CLI version
"""

__version__ = "1.47.0"
